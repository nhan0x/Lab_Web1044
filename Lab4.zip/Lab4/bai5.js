// Danh sách sản phẩm trong giỏ hàng
const cart = [
  { name: "Màn hình 24 inch", price: 150, quantity: 2 },
  { name: "Bàn phím Cơ", price: 80, quantity: 1 },
  { name: "Chuột Không Dây", price: 35, quantity: 2 },
  { name: "Tai nghe", price: 100, quantity: 1 }
];

// 1. Tính tổng tiền ban đầu bằng hàm reduce
const originalTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);

// 2. Kiểm tra điều kiện giảm giá
const discountRate = originalTotal > 500 ? 0.10 : 0;
const discountAmount = originalTotal * discountRate;
const finalTotal = originalTotal - discountAmount;

// In kết quả
console.log(`Tổng tiền ban đầu: $${originalTotal}`);
console.log(`Tiền giảm giá (10%): $${discountAmount}`);
console.log(`Tổng tiền cần thanh toán: $${finalTotal}`);