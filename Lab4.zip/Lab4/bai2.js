// Mảng số nguyên ban đầu (ví dụ dữ liệu)
const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// a) Tạo mảng mới evenNumbers chỉ chứa các số chẵn
const evenNumbers = numbers.filter(num => num % 2 === 0);
console.log("a) Mảng số chẵn (evenNumbers):", evenNumbers);

// b) Tạo mảng mới doubledEvenNumbers nhân đôi giá trị các số chẵn
const doubledEvenNumbers = evenNumbers.map(num => num * 2);
console.log("b) Mảng số chẵn nhân đôi (doubledEvenNumbers):", doubledEvenNumbers);