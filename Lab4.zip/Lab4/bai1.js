// Khởi tạo mảng ban đầu
let shoppingList = ["Trứng", "Thịt", "Rau"];

// a) In ra số lượng mặt hàng ban đầu
console.log("a) Số lượng mặt hàng ban đầu:", shoppingList.length);

// b) Thêm mặt hàng "Sữa" vào cuối danh sách
shoppingList.push("Sữa");
console.log("b) Danh sách sau khi thêm Sữa vào cuối:", shoppingList);

// c) Thêm mặt hàng "Bánh mì" vào đầu danh sách
shoppingList.unshift("Bánh mì");
console.log("c) Danh sách sau khi thêm Bánh mì vào đầu:", shoppingList);

// d) Xóa mặt hàng cuối cùng ra khỏi danh sách và in tên mặt hàng đó ra màn hình
let removedItem = shoppingList.pop();
console.log("d) Mặt hàng bị xóa ở cuối:", removedItem);

// e) In ra mặt hàng thứ 2 trong danh sách sau khi đã thay đổi
console.log("e) Mặt hàng thứ 2 (chỉ số 1) hiện tại:", shoppingList[1]);